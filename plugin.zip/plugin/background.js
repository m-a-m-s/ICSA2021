'use strict';

/**
 * These values need to be stored in the background page so they are stored longer
 * and are not forgotten whenever the popup closes.
 */
var logged_in = false;
var restapi = "https://ec2-3-22-225-201.us-east-2.compute.amazonaws.com/";// Public DNS of deployed REST API

chrome.runtime.onInstalled.addListener(function(details){
	// Reset all flags and load tasks
	chrome.storage.local.set({'user' : ""});
	chrome.storage.local.set({'chosenTask': ""});
	chrome.storage.local.set({'sessionId': ""});
	chrome.storage.local.set({'logged_in': false});
	chrome.storage.local.set({'selectedTask': false});
	chrome.storage.local.set({'executedQuery': false});
	loadTasks();
	console.log("Reset flags and loaded tasks");
});

function loadTasks() {
    $.ajax({
        url: restapi + 'tasks/all',
        type: 'GET',
        success: function(result) {
            console.log("GET TASKS SUCCESS");
            console.log(result);
            let tasks = result;
            chrome.storage.local.set({'tasks': tasks});
        },
        error: function(error) {
            console.log("GET TASKS ERROR");
            console.log(error);
        }
    });
}

/**
 * This listens to if any of the keys in storage are changed, and logs the old and new value
 */
chrome.storage.onChanged.addListener(function(changes, namespace) {
    for (var key in changes) {
         var storageChange = changes[key];
         console.log('Storage key "%s" in namespace "%s" changed. ' +
             'Old value was "%s", new value is "%s".',
             key,
             namespace,
             storageChange.oldValue,
             storageChange.newValue);
        //if logged in changed or haschosentask, send a message to all tabs to update the widgets
         if (key === "logged_in" && storageChange.newValue === undefined) {
            updateTextInWidgets();
         }
     }
});

/**
 * Listens to messages from the content script and returns with the appropriate response.
 * This listener validates and sanitizes all input to keep it secure.
 */
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.question.indexOf("Can you change the text? New task name is: ") !== -1) {
            updateTextInWidgets();
            sendResponse({answer: "text updated"});
        }
    }
);

// Add a `manifest` property to the `chrome` object.
chrome.manifest = chrome.app.getDetails();

var injectCodeIntoTab = function (tab) {
    chrome.tabs.executeScript(tab.id, {
        code: 'initializeContent();'
    });
}

function updateTextInWidgets() {
    // Get all windows
    chrome.windows.getAll({
        populate: true
    }, function (windows) {
        var i = 0, w = windows.length, currentWindow;
        for( ; i < w; i++ ) {
            currentWindow = windows[i];
            var j = 0, t = currentWindow.tabs.length, currentTab;
            for( ; j < t; j++ ) {
                currentTab = currentWindow.tabs[j];
                // Skip chrome:// pages
                if( ! currentTab.url.match(/(chrome):\/\//gi) ) {
                    injectCodeIntoTab(currentTab);
                }
            }
        }
    });
}

function changeLogin() {
    if(logged_in) {
        logged_in = false;
        //clearStorage();
    } else {
        logged_in = true;
    }
    // Get all windows
    updateTextInWidgets();
}

/**
 * Clear the storage of chrome, so that no functionality is left over.
 */
function clearStorage() {
    console.log("clearStorage called");
    chrome.storage.local.clear(function() {
        console.log("clearStorage");
        var error = chrome.runtime.lastError;
        if (error) {
            console.error(error);
        }
    });
}