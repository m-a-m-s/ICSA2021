'use strict';

var restapi = "https://ec2-3-22-225-201.us-east-2.compute.amazonaws.com/";// Public DNS of deployed REST API

var loadFunction = window.onload;

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");
    if (request.greeting == "resetWidgets"){
		$("#widget").remove();
		$(".relevanceSERPForm").remove();
		$(".causeSERPForm").remove();
		sendResponse({farewell: "Reseted widgets"});
	}
      
  });

window.onload = function(event) {
    initializeContent();
    if(loadFunction) loadFunction(event);
}

/**
 * This function initializes the content shown in the window.
 */
function initializeContent() {
    
	//alert("Initialization function is executed.");
	
	chrome.storage.local.get('logged_in', function(result) {
        if(result.logged_in) {         
			loadTasks();			
        } else {
            let pluginElements = $('.plugin');
            if(pluginElements.length !== 0) {
                pluginElements.attr("style", "display: none !important");
            }
        }
    });
}

/* --------------------------------------------------------------------------------------------------------
Initializing functions
*/

/**
 * Gets tasks from database and stores them in the chrome storage api.
 */
function loadTasks() {	
	chrome.storage.local.get(['tasks'], function(result) {
		if(result.tasks == undefined || result.tasks == "")
			
			$.ajax({
				url: restapi + 'tasks/all',
				type: 'GET',
				timeout:10000,
				success: function(result) {
					console.log("GET TASKS SUCCESS");
					console.log(result);
					let tasks = result;
					chrome.storage.local.set({'tasks': tasks});

				},
				error: function() {
					//showWarning("There was an issue fetching the tasks from the database.");
					alert("There was an issue fetching the tasks from the database.");
				}
			});

		}
	);
	
	createWidgets();
	showCorrectWidgets();
}

/* ---------------------------------------------------------------------------------------------------------
 Functions to create html elements and add them to the DOM.
 */

/**
 * Call functions to create widgets if they haven't been created yet.
 * They could have already been created if the content script is programmatically injected
 * using the background script.
 */
function createWidgets() {
    if($('.plugin').length === 0) {
        createNotificationWidget();
		//createWarningWidget();
        createTaskAndRelevanceWidget();
        addEventHandlersToWidgets();
        appendStyleSheet();
    }
}

/**
 * Creates a simple div where we can notify users
 */
function createNotificationWidget() {
    let notificationDiv = document.createElement("div");
    notificationDiv.id = "notification";
    notificationDiv.className = "plugin";
    let paragraphElement = document.createElement("p");
    notificationDiv.appendChild(paragraphElement);
    document.body.appendChild(notificationDiv);
    $("#notification").hide();
}

/**
 * Creates a simple div where we can notify users
 */
function createWarningWidget() {
    let notificationDiv = document.createElement("div");
    notificationDiv.id = "warning";
    notificationDiv.className = "plugin";
    let paragraphElement = document.createElement("p");
	notificationDiv.appendChild(paragraphElement);
    document.body.appendChild(notificationDiv);
    $("#warning").hide();
	$("#warning > p").hide();
}

/**
 * Creates all the elements for the task and relevance widget and appends it to the body of the DOM.
 */
function createTaskAndRelevanceWidget() {
    var widget = document.createElement("div");
    widget.id = "widget";
    widget.className = "plugin";

    var taskWidget = createTaskWidget();
    widget.appendChild(taskWidget);

    //var relevanceWidget = createRelevanceWidget();
    //widget.appendChild(relevanceWidget);

    document.body.appendChild(widget);
}

/**
 * Creates the task widget.
 *
 * @returns {HTMLDivElement} - The task widget.
 */
function createTaskWidget() {
    var taskWidget = document.createElement("div");
    taskWidget.id = "taskWidget";
    var collapseTaskButton = document.createElement("div");
    collapseTaskButton.id = "btnHideOrShowTaskWidget";
    var taskWidgetHeader = document.createElement("span");
    taskWidgetHeader.id = "taskWidgetHeader";
    // taskWidgetHeader.innerText = "Choose a task";
    var collapseArrow = document.createElement("i");
    collapseArrow.id = "arrowHideOrShowTaskWidget";
    collapseTaskButton.appendChild(collapseArrow);
    collapseTaskButton.appendChild(taskWidgetHeader);

    var taskForm = createSubmitTaskForm();
    taskWidget.appendChild(collapseTaskButton);
    taskWidget.appendChild(taskForm);

    return taskWidget;
}

/**
 * This creates the form to choose a task. It also creates the elements for the task description.
 *
 * @returns {HTMLFormElement} - The task form.
 */
function createSubmitTaskForm() {
    let taskForm = document.createElement("form");
    taskForm.id = "submitTaskForm";

    let taskSelect = document.createElement("select");
    taskSelect.id = "selectTask";
    putTaskOptionsInSelect(taskSelect);

    let br = document.createElement("br");
    taskSelect.appendChild(br);

    //expand description button
    let expandDescriptionDiv = document.createElement("div");
    expandDescriptionDiv.id = "btnHideOrShowTaskDescription";
    expandDescriptionDiv.className = "taskDescription";
    // let expandDescriptionArrow = document.createElement("i");
    // expandDescriptionArrow.id = "arrowHideOrShowTaskDescription";
    // expandDescriptionArrow.className = "taskDescription";
    let expandDescriptionButton = document.createElement("button");
    expandDescriptionButton.id = "buttonHideOrShowTaskDescription";
    expandDescriptionButton.type = "button";
    expandDescriptionButton.className = "taskDescription";
    expandDescriptionButton.innerText = "task description";

    expandDescriptionDiv.appendChild(expandDescriptionButton);

    //description paragraph
    let taskDescriptionContainer = document.createElement("div");
    taskDescriptionContainer.id = "taskDescriptionContainer";
    taskDescriptionContainer.className = "taskDescription";
    let taskDescription = document.createElement("p");
    taskDescription.id = "taskDescription";
    taskDescriptionContainer.appendChild(taskDescription);

    //select task button
    // let btnSelectTask = document.createElement("button");
    // btnSelectTask.id = "btnSelectTask";
    // btnSelectTask.setAttribute("type", "button");
    // btnSelectTask.setAttribute("value", "Select Task");
    // btnSelectTask.setAttribute("disabled", true);
    // btnSelectTask.innerText = "Select Task";

    taskForm.appendChild(taskSelect);
    taskForm.appendChild(expandDescriptionDiv);
    taskForm.appendChild(br);
    taskForm.appendChild(taskDescriptionContainer);
    // taskForm.appendChild(btnSelectTask);

    return taskForm;
}

/**
 * Gets all the tasks from the chrome storage API and puts them as options in the task select.
 *
 * @param taskSelect - the html element that it should be appended to.
 */
function putTaskOptionsInSelect(taskSelect) {
    let taskDefaultOption = document.createElement("option");
    taskDefaultOption.setAttribute("value", "");
    taskDefaultOption.innerText = "Choose a task";
    taskSelect.appendChild(taskDefaultOption);

    chrome.storage.local.get('tasks', function(result) {
        for (let i = 0; i < result.tasks.length; i++) {
            let opt = result.tasks[i];
            let optionElement = document.createElement("option");
            optionElement.textContent = opt.taskname;
            optionElement.value = opt.id;
            taskSelect.appendChild(optionElement);
        }
    });
}

/**
 * Creates the relevance widget.
 *
 * @returns {HTMLDivElement} - The relevance widget.
 */
function createRelevanceWidget() {
    var relevanceWidget = document.createElement("div");
    relevanceWidget.id = "relevanceWidget";
    var  collapseRelevanceButton = document.createElement("div");
    collapseRelevanceButton.id = "btnHideOrShowRelevanceWidget"; //used to be hideOrShowRelevanceWidget
    var relevanceWidgetHeader = document.createElement("span");
    relevanceWidgetHeader.id = "relevanceWidgetHeader"; //used to be btnCollapseRelevance
    var collapseArrow = document.createElement("i");
    collapseArrow.id = "arrowHideOrShowRelevanceWidget";
    collapseRelevanceButton.appendChild(collapseArrow);
    collapseRelevanceButton.appendChild(relevanceWidgetHeader);
    var relevanceForm = createSubmitRelevanceForm("", "inpRelevanceForm", "", "btnSubmitRelevance", true);

    relevanceWidget.appendChild(collapseRelevanceButton);
    relevanceWidget.appendChild(relevanceForm);

    return relevanceWidget;
}

/**
 * Creates the div element with the choices for the relevances.
 * @param relevanceDivClassName - class name for the relevance div.
 * This is needed to distinguish between the different google result.
 * @param relevanceDivId
 * @param btnSubmitClassName
 * @param btnSubmitId
 * @param needBreakline - the options in the widget need breaklines in between them, but not on google.
 * @returns {HTMLDivElement} - The relevance form.
 */
function createSubmitRelevanceForm(relevanceDivClassName, relevanceDivId, btnSubmitClassName, btnSubmitId, needBreakline) {
    let radioButtonExtraString = "";
    if(relevanceDivClassName !== "") {
        radioButtonExtraString = relevanceDivClassName.split(" ")[1]; //number of result
    }
    var relevanceForm = document.createElement("div");
    if(relevanceDivClassName !== "") relevanceForm.className = relevanceDivClassName;
    relevanceForm.id = relevanceDivId;
    var labelText = 'No Relevance <span class="tooltipsrtmmstext">The web page has nothing to do with the ' +
        'task. It has no relevant information.</span>';
    var i1 = createRelevanceRadioButton("1", radioButtonExtraString, labelText);
    labelText = "Low Relevance <span class=\"tooltipsrtmmstext\">The web page contains relevant information, " +
        "which is only remotely relevant to solving the given task, but might help for refining " +
        "the search.</span>";
    var i2 = createRelevanceRadioButton("2", radioButtonExtraString, labelText);
    labelText = "Medium Relevance <span class=\"tooltipsrtmmstext\">The web page addresses another problem " +
        "not similar to the task at hand, but it provides some relevant information to the task, " +
        "which could be an answer to the searching goal. Nevertheless, the provided information " +
        "does not consider specifically the task’s requirements.</span>";
    var i3 = createRelevanceRadioButton("3", radioButtonExtraString, labelText);
    labelText = "High Relevance <span class=\"tooltipsrtmmstext\">The web page addresses a similar problem to " +
        "the task and contains useful information. The web page provides an answer to the searching goal, " +
        "and fulfills at least one requirement of the task.</span>";
    var i4 = createRelevanceRadioButton("4", radioButtonExtraString, labelText);
    labelText = "Very High Relevance <span class=\"tooltipsrtmmstext\">The web page discusses a similar problem " +
        "to the task and contains useful information. The web page provides an answer to the searching goal, " +
        "and fulfills more than one requirement of the task.</span>";
    var i5 = createRelevanceRadioButton("5", radioButtonExtraString, labelText);
    //var submitRelevanceButton = document.createElement("button");
    //submitRelevanceButton.setAttribute("type", "button");
    //submitRelevanceButton.setAttribute("value", "Submit Relevance");
    //submitRelevanceButton.setAttribute("disabled", true);
    //submitRelevanceButton.innerText = "Submit Relevance";
    //if(btnSubmitClassName !== "") submitRelevanceButton.className = btnSubmitClassName;
    //submitRelevanceButton.id = btnSubmitId;
    relevanceForm.appendChild(i1);
    if(needBreakline) relevanceForm.appendChild(document.createElement("br"));
    relevanceForm.appendChild(i2);
    if(needBreakline) relevanceForm.appendChild(document.createElement("br"));
    relevanceForm.appendChild(i3);
    if(needBreakline) relevanceForm.appendChild(document.createElement("br"));
    relevanceForm.appendChild(i4);
    relevanceForm.appendChild(document.createElement("br")); //Needs to be there in the widget and in google.
    relevanceForm.appendChild(i5);
    if(needBreakline) relevanceForm.appendChild(document.createElement("br"));
    //relevanceForm.appendChild(submitRelevanceButton);

    return relevanceForm;
}

/**
 * This function creates the radio button with the label for the relevance scores.
 * @param value
 * @param relevanceDivClassName
 * @param labelText
 * @returns {HTMLSpanElement}
 */
function createRelevanceRadioButton(value, relevanceDivClassName, labelText) {
    var spanElement = document.createElement("span");
    var radioButton = document.createElement("input");
    radioButton.setAttribute("type", "radio");
    radioButton.setAttribute("value", value);
    radioButton.setAttribute("name", "relevance" + relevanceDivClassName);
    radioButton.setAttribute("id", "rel" + value + relevanceDivClassName);
    var labelElement = document.createElement("label");
    labelElement.setAttribute("for", "rel" + value + relevanceDivClassName);
    labelElement.className = "tooltipsrtmms";
    labelElement.innerHTML = labelText;
    spanElement.appendChild(radioButton);
    spanElement.appendChild(labelElement);
    return spanElement;
}

/**
 * This function creates the div with the choices for the cause for the use's
 * relevance score.
 *
 * @param causeFormClassName
 * @param causeFormId
 * @param btnSubmitCauseClassName
 * @param btnSubmitCauseId
 * @param needBreakline
 * @returns {HTMLDivElement}
 */
function createSubmitCauseForm(causeFormClassName, causeFormId, btnSubmitCauseClassName, btnSubmitCauseId, needBreakline) {
    let checkboxExtraString = "";
    if (causeFormClassName !== "") {
        checkboxExtraString = causeFormClassName.split(" ")[1]; //number of result
    }
    let causeForm = document.createElement("div");
    if (causeFormClassName !== "") causeForm.className = causeFormClassName;
    causeForm.id = causeFormId;
    var labelText = "Solution's description" +
        "<span class='tooltipsrtmmstext'>The web page contains general information " +
        "on an architectural solution. For example, general information on the supported " +
        "features of a technology or descriptions of architectural patterns</span>";
    var i1 = createCauseCheckBox("1", checkboxExtraString, labelText);
    labelText = "Development and implementation guide" +
        "<span class='tooltipsrtmmstext'>The web page contains information on how to implement " +
        "an architectural solution (examples, development guides, installation " +
        "guides, code examples)</span>";
    var i2 = createCauseCheckBox("2", checkboxExtraString, labelText);
    labelText = "Solution alternatives<span class='tooltipsrtmmstext'>" +
        "The web page containes multiple (alternative) solution options for a " +
        "certain design issue. For example, lists of broker technologies, " +
        "lists of SOA patterns. The architectural options could be listed in " +
        "text or as a comparison of different solution options.</span>";
    var i3 = createCauseCheckBox("3", checkboxExtraString, labelText);
    labelText = "Solutions benefits<span class='tooltipsrtmmstext'>" +
        "The web page contains information about the advantages of certain " +
        "architectural solutions. For example, the advantages of using a certain " +
        "technology regarding its performance, which can be supported with benchmarks " +
        "or tests. Those advantages might be part of a comparison with other options.</span>";
    var i4 = createCauseCheckBox("4", checkboxExtraString, labelText);
    labelText = "Solution drawbacks<span class='tooltipsrtmmstext'>The web page " +
        "contains information about the disadvantages of certain architectural solutions, or even " +
        "discourages its application. For example, the disadvantages of using a certain technology " +
        "regarding its security or Information on when not to decide on an architectural solution.</span>";
    var i5 = createCauseCheckBox("5", checkboxExtraString, labelText);
    labelText = "UseCase<span class='tooltipsrtmmstext'>The web page contains " +
        "explanations about the architecture of a specific system. This includes description for an " +
        "existing architectural design of a specific system, or explanations about certain design decisions " +
        "of a specific system. For example, a web page explains the software architecture of Facebook.</span>";
    var i6 = createCauseCheckBox("6", checkboxExtraString, labelText);

    var othersElement = document.createElement("div");
    labelText = "Others<span class='tooltipsrtmmstext'>The web page contains other " +
        "relevant architectural information. Please write down which other information you found.</span>";
    var labelElement = document.createElement("label");
    labelElement.htmlFor = "cause7" + checkboxExtraString;
    labelElement.className = "tooltipsrtmms";
    labelElement.innerHTML = labelText;
    let textInput = document.createElement("textarea");
    textInput.id = "cause7" + checkboxExtraString;
    textInput.name = "cause7" + checkboxExtraString;
    textInput.rows = 4;
    textInput.cols = 70;
    othersElement.appendChild(labelElement);
    othersElement.appendChild(document.createElement("br"))
    othersElement.appendChild(textInput);

    var submitCauseButton = document.createElement("button");
    submitCauseButton.type = "button";
    submitCauseButton.value = "Submit relevance and knowledge types";
    submitCauseButton.innerText = "Submit relevance and knowledge types";
    if(btnSubmitCauseClassName !== "") submitCauseButton.className = btnSubmitCauseClassName;
    submitCauseButton.id = btnSubmitCauseId;

    causeForm.appendChild(i1);
    if(needBreakline) causeForm.appendChild(document.createElement("br"));
    causeForm.appendChild(i2);
    if(needBreakline) causeForm.appendChild(document.createElement("br"));
    causeForm.appendChild(i3);
    if(needBreakline) causeForm.appendChild(document.createElement("br"));
    causeForm.appendChild(i4);
    if(needBreakline) causeForm.appendChild(document.createElement("br"));
    causeForm.appendChild(i5);
    if(needBreakline) causeForm.appendChild(document.createElement("br"));
    causeForm.appendChild(i6);
    causeForm.appendChild(document.createElement("br"));
    causeForm.appendChild(othersElement);
    causeForm.appendChild(submitCauseButton);

    return causeForm;
}

/**
 *
 * @param value
 * @param causeDivClassName
 * @param labelText
 * @returns {HTMLSpanElement}
 */
function createCauseCheckBox(value, causeDivClassName, labelText) {
    var spanElement = document.createElement("span");
    var checkBox = document.createElement("input");
    checkBox.type = "checkbox";
    checkBox.value = value;
    checkBox.name = value + causeDivClassName;
    checkBox.id = "cause" + value + causeDivClassName;
    var labelElement = document.createElement("label");
    labelElement.htmlFor = "cause" + value + causeDivClassName;
    labelElement.className = "tooltipsrtmms";
    labelElement.innerHTML = labelText;
    spanElement.appendChild(checkBox);
    spanElement.appendChild(labelElement);
    spanElement.style.display = "inline-block";
    return spanElement;
}

/**
 * This function creates the relevance forms for the SERP on the first page of Google.
 * While creating the form per search result, it also fetches and stores the search result url.
 */
function createRelevanceFormsForSERP(taskname, searchquery_id, isAlreadyStored) {
    
	chrome.storage.local.get(['executedQuery'], function(result) {
		console.log('Logged_in value currently is ' + result.logged_in);
		if (result.executedQuery) {	  
		  if($(".relevanceSERPForm").length === 0) {
			//ask Relevance inside Google and retrieve urls
			var resDivs = document.getElementsByClassName("g");
			var cnt = 0; //cnt is index of the search results
			var i = 0;
			while(cnt < 10 && resDivs[i] !== undefined) {
				if(resDivs[i].classList.length === 1 &&
					(resDivs[i].parentElement.id === "rso" || resDivs[i].parentElement.id === "")) {
					var resultUrl = resDivs[i].querySelector("a").href;
					// Remove the string after the start of "#:~:text=", since that is not the actual href
					// of the result.
					var indexOfFeaturedSnippet = resultUrl.indexOf("#:~:text=");
					if(indexOfFeaturedSnippet !== -1) {
						resultUrl = resultUrl.substring(0, indexOfFeaturedSnippet);
					}
					var resultTitle = resDivs[i].querySelector("a > h3").innerText;
					var relevanceForm = createRelevanceFormForSERP(searchquery_id, taskname, cnt, resultTitle, resultUrl);
					var causeForm = createCauseFormForSERP(searchquery_id, taskname, cnt, resultTitle, resultUrl);
					resDivs[i].appendChild(relevanceForm);
					resDivs[i].appendChild(causeForm);
					if(!isAlreadyStored) {
						storeSearchResult(resultUrl, cnt + 1, false, searchquery_id);
					} else {
						// console.log("select relevance for existing result");
						selectRelevanceAndCauseForExistingResult(resultUrl, searchquery_id, cnt);
					}
					cnt++;
				}
				i++;
			}
			addEventHandlersToRelevanceForms();
		}
		}
	  });
}

/**
 * This function creates the relevance form.
 *
 * @param searchquery_id
 * @param taskname
 * @param cnt
 * @param resultTitle
 * @param resultUrl
 * @returns {HTMLDivElement}
 */
function createRelevanceFormForSERP(searchquery_id, taskname, cnt, resultTitle, resultUrl) {
    var relevanceDiv = document.createElement("div");
    relevanceDiv.className = "relevanceSERPForm plugin " + searchquery_id;
    relevanceDiv.title = resultTitle;
    var relevanceHeader = document.createElement("h3");
    relevanceHeader.className = "relevanceHeader";
    relevanceHeader.innerText = "How would you rate the relevance of this website to task: \"" + taskname + "\"?";
    relevanceDiv.append(relevanceHeader);
    var relevanceFormClassName = "inpRelevance " + numberToString(cnt) + " " + resultUrl + " -1";
    var btnSubmitRelevanceClassName = "btnSubmitRelevance " + numberToString(cnt);
    var btnSubmitId = "btnSubmitRelevance" + numberToString(cnt);
    var relevanceForm = createSubmitRelevanceForm(relevanceFormClassName, numberToString(cnt), btnSubmitRelevanceClassName, btnSubmitId, false);
    relevanceDiv.appendChild(relevanceForm);
    $("#" + btnSubmitId).attr("disabled", true);
    return relevanceDiv;
}

/**
 * This function creates the cause form.
 *
 * @param searchquery_id
 * @param taskname
 * @param cnt
 * @param resultTitle
 * @param resultUrl
 * @returns {HTMLDivElement}
 */
function createCauseFormForSERP(searchquery_id, taskname, cnt, resultTitle, resultUrl) {
    var causeDiv = document.createElement("div");
    causeDiv.className = "causeSERPForm plugin " + searchquery_id;
    causeDiv.title = resultTitle;
    var causeHeader = document.createElement("h3");
    causeHeader.innerText = "Which knowledge exist in this website, which support solving task: \"" + taskname + "\"?";
    causeDiv.append(causeHeader);
    var causeFormClassName = "inpCause " + numberToString(cnt) + " " + resultUrl + " -1";
    var btnSubmitCauseClassName = "btnSubmitCause " + numberToString(cnt);
    var btnSubmitCauseId = "btnSubmitCause" + numberToString(cnt);
    var causeForm = createSubmitCauseForm(causeFormClassName, numberToString(cnt), btnSubmitCauseClassName, btnSubmitCauseId, false);
    causeDiv.append(causeForm);
    return causeDiv;
}

/* ---------------------------------------------------------------------------------------------------------
 Functions to add event handlers to the created elements.
 */

/**
 * Function to add event handlers to task and relevance widget.
 */
function addEventHandlersToWidgets() {
    handleHideOrShowEvents();
    handleChangeOptionFromTaskSelect();
    // handleSelectTask(); // REMOVED THIS SINCE NOW USERS CHOOSE A TASK BY JUST SELECTING ONE FROM THE DROPDOWN
    handleChangeRelevanceScoreSelection();
    handleSelectRelevance();
}

/**
 * Adds event handlers to the hide or show containers of the task and relevance widget.
 */
function handleHideOrShowEvents() {
    $("#btnHideOrShowTaskWidget").on("click", function () {
        hideOrShowTaskWidget();
    });

    $("#btnHideOrShowRelevanceWidget").on("click", function () {
        hideOrShowRelevanceWidget();
    });

    $("#btnHideOrShowTaskDescription").on("click", function () {
       hideOrShowTaskDescription();
    });
}

/**
 * Adds event handler to the task select.
 */
function handleChangeOptionFromTaskSelect() {
    $("#selectTask").change(function() {
        showAndEnableCorrectEventsInTaskForm();
        handleSelectTask();
    });
}

/**
 * Adds event handler to the select task button.
 */
function handleSelectTask() {
    // $("#btnSelectTask").on("click", function() {
        chrome.storage.local.get(['logged_in'], function(result) {
			// Make sure that the user is logged in before changing the task and creating a new session
			if (result.logged_in) {
			    if($("#taskWidgetHeader").text() === "View or Select a New Task") {
					stopCurrentSession();
				}
				selectTask(parseInt($("#selectTask").val()));
			}
		});
    // });
}

/**
 * Adds event handler to the relevance score radio buttons to see if they get selected.
 */
function handleChangeRelevanceScoreSelection() {
    $("input[name=\"relevance\"]").on("click", function() {
        let submittedRelevance = $(this).parent().parent().attr("class");
        let currentSelectedRelevance = $("input[name=\"relevance\"]:checked").val();
        $(this).parent().parent().addClass($("input[name=\"relevance\"]:checked"));
       //TODO check if the input clicked is the same as submitted relevance and then disable the button
        if(submittedRelevance === undefined || (submittedRelevance !== currentSelectedRelevance)) {
            $("#btnSubmitRelevance").attr("disabled", false);
        } else {
            $("#btnSubmitRelevance").attr("disabled", true);
        }
    });
}

/**
 * Adds event handler to the select relevance button.
 */
function handleSelectRelevance() {
    $("#btnSubmitRelevance").on("click", function() {
        let relevanceScore = parseInt($("input[name=\"relevance\"]:checked").val());
        let searchquery_id = $("#widget").attr("class").split(" ")[1];
        selectRelevance(relevanceScore, window.location.href, searchquery_id);
        //showNotificationForSelectingRelevance(
        //    document.title,
        //    relevanceScore,
        //    $("#btnSubmitRelevance").text() === "Update Relevance"
        //);
        $(this).parent().addClass("" + relevanceScore);
        $(this).attr("disabled", true);
        $(this).text("Update Relevance");
        hideRelevanceForm();
    });
}

/**
 * Function to add event handlers to the relevance form in the Google Results page.
 */
function addEventHandlersToRelevanceForms() {
    handleChangeRelevanceScoreSelectionOnSERP();
    handleSelectRelevanceOnSERP();
    handleSubmitCauseOnSERP();
	//handleSelectRelevanceAndCauseOnSERP();
}

/**
 * Adds event handler to the relevance score radio buttons in the relevance forms
 * on the first page of google to see if they got selected.
 */
function handleChangeRelevanceScoreSelectionOnSERP() {
    $("input[name^=\"relevance\"]").on("click", function() {
        let numberOfResult = this.parentElement.parentElement.classList[1];
        let currentRelevance = $("div#" + numberOfResult + " > span > input[name^=\"relevance\"]:checked").val();
        let submittedRelevance = $("div#" + numberOfResult).attr("class").split(" ")[3];
        if(submittedRelevance === "-1") {
            $("#btnSubmitRelevance" + numberOfResult).attr("disabled", false);
        } else {
            if(submittedRelevance === currentRelevance) {
                $("#btnSubmitRelevance" + numberOfResult).attr("disabled", true);
            } else {
                $("#btnSubmitRelevance" + numberOfResult).attr("disabled", false);
            }
        }
    });
}

/**
 * Adds event handler to the select relevance button in the relevance forms
 * on the first page of google.
 */
function handleSelectRelevanceOnSERP() {
    $(".btnSubmitRelevance").on("click", function() {
        let numberOfResult = $(this).attr("class").split(" ")[1];
        let relevanceScore = parseInt($("div#" + numberOfResult + " > span > input[name^=\"relevance\"]:checked").val());
        let relevanceDiv = $("div#" + numberOfResult);
        let previousRelevance = relevanceDiv.attr("class").split(" ")[3];
        let searchquery_id = relevanceDiv.parent().attr("class").split(" ")[2];
        relevanceDiv.removeClass(previousRelevance);
        relevanceDiv.addClass(relevanceScore);
        $(this).attr("disabled", true);
        selectRelevance(relevanceScore, relevanceDiv.attr("class").split(" ")[2], searchquery_id);
        //showNotificationForSelectingRelevance(
        //    relevanceDiv.parent().attr("title"),
        //    relevanceScore,
        //    $("#btnSubmitRelevance" + numberOfResult).text() === "Update Relevance"
        //);
        if(!($("#btnSubmitRelevance" + numberOfResult).text() === "Update Relevance")) {
            $("#btnSubmitRelevance" + numberOfResult).text("Update Relevance");
        }
    });
}

function handleSelectRelevanceAndCauseOnSERP() {
    $(".btnSubmitCause").on("click", function() {
		
		alert("event handler");
		
		let numberOfResult = $(this).attr("class").split(" ")[1];
        let relevanceScore = parseInt($("div#" + numberOfResult + " > span > input[name^=\"relevance\"]:checked").val());
        let relevanceDiv = $("div#" + numberOfResult);
        let previousRelevance = relevanceDiv.attr("class").split(" ")[3];
        let searchquery_id = relevanceDiv.parent().attr("class").split(" ")[2];
        relevanceDiv.removeClass(previousRelevance);
        relevanceDiv.addClass(relevanceScore);
        $(this).attr("disabled", true);
        
		selectRelevanceAndCause(numberOfResult, relevanceScore, relevanceDiv.attr("class").split(" ")[2], searchquery_id);
		      
        let clickedSubmitButton = $("#btnSubmitCause" + numberOfResult);   
        //if(!(clickedSubmitButton.text() === "Update relevance and knowledge types")) {
        //    clickedSubmitButton.text("Update relevance and knowledge types");
        //}		
    });
}

function selectRelevanceAndCause(numberOfResult, relevanceScore, searchResultUrl, searchquery_id) {

	let causeSolutionDescription = $("#cause1" + numberOfResult).is(":checked");
    let causeDevelopImplementGuide = $("#cause2" + numberOfResult).is(":checked");
    let causeSolutionAlternatives = $("#cause3" + numberOfResult).is(":checked");
    let causeSolutionBenefits = $("#cause4" + numberOfResult).is(":checked");
    let causeSolutionDrawbacks = $("#cause5" + numberOfResult).is(":checked");
    let causeUseCase = $("#cause6" + numberOfResult).is(":checked");
    let causeOthers = $("#cause7" + numberOfResult).val();

    let cause = "" + causeSolutionDescription + "," + causeDevelopImplementGuide +
                "," + causeSolutionAlternatives + "," + causeSolutionBenefits + "," +
                causeSolutionDrawbacks + "," + causeUseCase + "," + causeOthers;
    console.log(cause);

	let encodedUrl = encodeURIComponent(searchResultUrl);
	encodedUrl = encodedUrl.replaceAll("%", "@");
	
	let encodedCause = encodeURIComponent(cause);
	encodedCause = encodedCause.replaceAll("%", "@");
	
    let url = restapi + 'urls/url=' + encodedUrl + '/searchqueryId=' + searchquery_id + '/relevance=' + relevanceScore + '/cause=' + encodedCause;
    $.ajax({
        url: url,
        type: "GET",
		timeout:10000,
        success: function(result) {
            console.log(result);
			showNotificationForSelectingRelevance(
				searchResultUrl,
				relevanceScore,
				false
			);
        },
        error: function(err) {
			//showWarning("There was an issue fetching the url to update the relevance for.");
			alert("There was an issue submitting the relevance and knowledge types to the server.");
        }
    });

}


/**
 * Adds event handler to the submit cause button in the relevance forms
 * on the first page of google.
 */
function handleSubmitCauseOnSERP() {
    $(".btnSubmitCause").on("click", function() {
        let numberOfResult = $(this).attr("class").split(" ")[1];
		let relevanceScore = parseInt($("div#" + numberOfResult + " > span > input[name^=\"relevance\"]:checked").val());
		if(isNaN(relevanceScore)){
			relevanceScore = 1;
		}
		let relevanceDiv = $("div#" + numberOfResult);
        let searchquery_id = relevanceDiv.parent().attr("class").split(" ")[2];
        //selectCause(numberOfResult, relevanceDiv.attr("class").split(" ")[2], searchquery_id);
		selectRelevanceAndCause(numberOfResult, relevanceScore, relevanceDiv.attr("class").split(" ")[2], searchquery_id);
        let clickedSubmitButton = $("#btnSubmitCause" + numberOfResult);
        
        if(!(clickedSubmitButton.text() === "Update relevance and knowledge types")) {
            clickedSubmitButton.text("Update relevance and knowledge types");
        }
    });
}

/**
 * Listens to user clicks on links
 */
function handleClicks() {
    $("a").on("click", function() {
        let clickedUrl = $(this).prop("href");
        var indexOfFeaturedSnippet = clickedUrl.indexOf("#:~:text=");
        if(indexOfFeaturedSnippet !== -1) {
            clickedUrl = clickedUrl.substring(0, indexOfFeaturedSnippet);
        }

        if(onFirstPageOfGoogle()) {
            let searchquery_id = $(".relevanceSERPForm")[0].classList[2];
            // updateClickedInUrl(clickedUrl, searchquery_id);
        } else {
            let searchquery_id = $("#widget").attr("class").split(" ")[1];
            let rankingoogle = $("#widget").attr("class").split(" ")[2];

            //let encodedUrl = clickedUrl.replaceAll("/", "@2F");
            //encodedUrl = encodedUrl.replaceAll("#", "%23");
			let encodedUrl = encodeURIComponent(clickedUrl);
			encodedUrl = encodedUrl.replaceAll("%", "@");
            // See if url is already in the database, if so, update clicked if needed.
            // Otherwise, store the url with the correct value for clicked.
            $.ajax({
                url: restapi + 'urls/url=' + encodedUrl + '/searchqueryId=' + searchquery_id,
                type: 'GET',
				timeout:10000,
                success: function(result) {
                    console.log("URL EXISTS");
                    console.log(result);
                    if(!result.clicked) {
                        result.clicked = true;
                        updateURL(result.id, result, false);
                    }
                },
                error: function() {
                    storeSearchResult(clickedUrl, rankingoogle, true, searchquery_id);
                }
            });
        }
    });
}
/* ---------------------------------------------------------------------------------------------------------
 Functions to handle events such as choose task.
 */

/**
 * This function hides or show the task widget depending on the current state of the visibility.
 */
function hideOrShowTaskWidget() {
    if($("#submitTaskForm").is(":visible")) {
        hideTaskForm();
    } else {
        showTaskForm();
    }
}

/**
 * Hides the task form and transforms the arrow accordingly.
 */
function hideTaskForm() {
    $("#submitTaskForm").hide();
    $("#arrowHideOrShowTaskWidget").css("transform", "rotate(-135deg)");
    hideTaskDescription();
}

/**
 * Shows the task form and transforms the arrow accordingly.
 */
function showTaskForm() {
    $("#submitTaskForm").show();
    $("#arrowHideOrShowTaskWidget").css("transform", "rotate(45deg)");
}

/**
 * This function hides or shows the relevance widget depending on the current state of the visibility.
 */
function hideOrShowRelevanceWidget() {
    if($("#inpRelevanceForm").is(":visible")) {
        hideRelevanceForm();
    } else {
        showRelevanceForm();
    }
}

/**
 * Hides the relevance form and transforms the arrow accordingly.
 */
function hideRelevanceForm() {
    $("#inpRelevanceForm").hide();
    $("#arrowHideOrShowRelevanceWidget").css("transform", "rotate(-135deg)");
}

/**
 * Shows the relevance form and transforms the arrow accordingly.
 */
function showRelevanceForm() {
    $("#inpRelevanceForm").show();
    $("#arrowHideOrShowRelevanceWidget").css("transform", "rotate(45deg)");
}

/**
 * This function hides or shows the task description depending on the current state of the visibility.
 */
function hideOrShowTaskDescription() {
    if($("#taskDescriptionContainer").is(":visible")) {
        hideTaskDescription();
    } else {
        showTaskDescription();
    }
}

/**
 * Hides the task description and transforms the arrow accordingly.
 */
function hideTaskDescription() {
    $("#taskDescriptionContainer").hide();
    // $("#arrowHideOrShowTaskDescription").css("transform", "rotate(-135deg)");
    $("#widget").attr("style", "width: 250px !important; max-width: 250px !important;");
}

/**
 * Shows the task description and transforms the arrow accordingly.
 */
function showTaskDescription() {
    $("#taskDescriptionContainer").show();
    // $("#arrowHideOrShowTaskDescription").css("transform", "rotate(45deg)");
    $("#widget").attr("style", "max-width: 750px !important;");
}

/**
 * This selects the task by updating the storage, the text in the widgets and starting a session.
 *
 * @param taskId
 */
function selectTask(taskId) {
    chrome.storage.local.set({'chosenTask': taskId});
	chrome.storage.local.set({'selectedTask': true});
    chrome.storage.local.get(['chosenTask', 'tasks'], function(result) {
        let taskname = result.tasks[result.chosenTask - 1].taskname;
        showNotificationForSelectingTask(taskname, $("#taskWidgetHeader").text() === "View or Select a New Task");
        
		// Update tasks widget
        hideTaskForm();
		showAndEnableCorrectEventsInTaskForm();
		
		// Remove relevance form
		$(".relevanceSERPForm").remove();
		$(".causeSERPForm").remove();
		
		//chrome.runtime.sendMessage({question: "Can you change the text? New task name is: " + taskname}, function (response) {
        //   console.log("update text response answer: " + response.answer);
        //});
    });
	
	chrome.storage.local.get('sessionId', function(result) {
      console.log(result.sessionId);
      if(result.sessionId !== undefined && result.sessionId !== "") {
        stopSession(result.sessionId);
      }
    });
	
    startSession(taskId);
	chrome.storage.local.set({'executedQuery': false});
}

/**
 * Stops the session by updating the current session using the REST API.
 * @param sessionId
 * @param datetime_finish
 */
function stopSession(sessionId) {
  let datetime_finish = new Date(Date.now());
  console.log("datetime_finish: " + datetime_finish);
  $.ajax({
    url: restapi + 'sessions/' + sessionId,
    type: 'GET',
	timeout:10000,
    success: function(result) {
       console.log("SUCCESS GET SESSION");
       console.log(result);
       let sessionObject = result;
       sessionObject.datetimefinish = datetime_finish;
       updateSession(sessionObject.id, sessionObject);
    },
    error: function() {
      //showWarning("There was a problem fetching the current session from the database.");
	  alert("There was a problem fetching the current session from the database.");
    }
  });
}

/**
 * Updates the session in the database using a REST call.
 * @param sessionId
 * @param sessionObject
 */
function updateSession(sessionId, sessionObject) {
  let url = restapi + 'sessions/' + sessionId;
  $.ajax({
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    url: url,
    type: 'PUT',
	timeout:10000,
    data: JSON.stringify(sessionObject),
    dataType: 'json',
    success: function(result) {
      console.log("SUCCESS UPDATE SESSION");
      console.log(result);
    },
    error: function() {
      //showWarning("There was a problem updating the session record in the database.");
	  alert("There was a problem updating the session record in the database.");
    }
  });
}

/**
 * This function updates the texts in widgets with the correct task name.
 * It also updates the text of certain buttons to make it clear to the users that
 * they have selected a task.
 */
function updateTextInWidgets() {
    chrome.storage.local.get(['chosenTask', 'tasks'], function(result) {
       let taskname = result.tasks[result.chosenTask - 1].taskname;
        // $("#btnSelectTask").val("Choose a New Task");
        hideTaskForm();
        // $("#btnSelectTask").text("Choose a New Task");
        $("#taskWidgetHeader").html("View or Select a New Task");
        $("#relevanceWidgetHeader").text("How would you rate the relevance of this website to task: \"" + taskname + "\"?");
        $("h3.relevanceHeader").text("What would you rate the relevance of this result to task: \"" + taskname + "\"?");
        $("#btnSubmitRelevance").attr("disabled", true);
        }
    );
}

/**
 * Starts a session by creating a new session and storing it in the database.
 *
 * @param taskId
 */
function startSession(taskId) {
    chrome.storage.local.get('user', function(result) {
        let url = restapi + 'sessions/add';
        let data = {userid: result.user, taskid: taskId};
        $.ajax({
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            url: url,
            type: 'POST',
			timeout:10000,
            data: JSON.stringify(data),
            dataType: 'json',
            success: function(result) {
                console.log("SUCCESS START SESSION:");
                console.log(result);
                chrome.storage.local.set({'sessionId': result.id});
            },
            error: function() {
                //showWarning("There was a problem creating a new session.");
				alert("There was a problem creating a new session.");
            }
        });
    });
}

/**
 * This function gets the current session out of the database
 * by using a REST call and updates the datetimeFinish field
 * of the current session.
 */
function stopCurrentSession() {
    chrome.storage.local.get('sessionId', function(result) {
        let currentSession = result.sessionId;
        let url = restapi + 'sessions/' + currentSession;
        let datetime_finish = new Date(Date.now());
        console.log("datetime_finish: " + datetime_finish);
        $.ajax({
            url: restapi + 'sessions/' + sessionId,
            type: 'GET',
			timeout:10000,
            success: function (result) {
                console.log("SUCCESS GET SESSION");
                console.log(result);
                let sessionObject = result;
                sessionObject.datetimefinish = datetime_finish;
                updateSession(sessionObject.id, sessionObject);
            },
            error: function () {
                //showWarning("There was an error issue fetching the current session.");
				alert("There was an error issue fetching the current session.");
            }
        });
    });
}

/**
 * Selects relevance for current search result.
 */
function selectRelevance(relevanceScore, searchResultUrl, searchquery_id) {
    //let encodedUrl = searchResultUrl.replaceAll("/", "@2F");
    //encodedUrl = encodedUrl.replaceAll("#", "%23");
	let encodedUrl = encodeURIComponent(searchResultUrl);
	encodedUrl = encodedUrl.replaceAll("%", "@");
    let url = restapi + 'urls/url=' + encodedUrl + '/searchqueryId=' + searchquery_id;
    $.ajax({
        url: url,
        type: "GET",
		timeout:10000,
        success: function(result) {
            console.log(result);
            let urlObject = result;
            urlObject.relevance = relevanceScore;
            updateURL(urlObject.id, urlObject, true);
			showNotificationForSelectingRelevance(
				searchResultUrl,
				relevanceScore,
				false
			);
        },
        error: function(err) {
			//showWarning("There was an issue fetching the url to update the relevance for.");
			alert("There was an issue fetching the url to update the relevance for.");
        }
    });
}

/**
 * Updates the cause value for the current search result.
 * @param numberOfResult
 * @param searchResultUrl
 * @param searchqueryId
 */
function selectCause(numberOfResult, searchResultUrl, searchqueryId) {
    let causeSolutionDescription = $("#cause1" + numberOfResult).is(":checked");
    let causeDevelopImplementGuide = $("#cause2" + numberOfResult).is(":checked");
    let causeSolutionAlternatives = $("#cause3" + numberOfResult).is(":checked");
    let causeSolutionBenefits = $("#cause4" + numberOfResult).is(":checked");
    let causeSolutionDrawbacks = $("#cause5" + numberOfResult).is(":checked");
    let causeUseCase = $("#cause6" + numberOfResult).is(":checked");
    let causeOthers = $("#cause7" + numberOfResult).val();

    let cause = "" + causeSolutionDescription + "," + causeDevelopImplementGuide +
                "," + causeSolutionAlternatives + "," + causeSolutionBenefits + "," +
                causeSolutionDrawbacks + "," + causeUseCase + "," + causeOthers;
    console.log(cause);

    //let encodedUrl = searchResultUrl.replaceAll("/", "@2F");
    //encodedUrl = encodedUrl.replaceAll("#", "%23");
	let encodedUrl = encodeURIComponent(searchResultUrl);
	encodedUrl = encodedUrl.replaceAll("%", "@");
    let url = restapi + 'urls/url=' + encodedUrl + '/searchqueryId=' + searchqueryId;
    $.ajax({
        url: url,
        type: "GET",
		timeout:10000,
        success: function(result) {
            console.log(result);
            let urlObject = result;
            urlObject.cause = cause;
            updateURL(urlObject.id, urlObject, false);
			showNotificationForSubmittingCause(
				searchResultUrl,
				false
			);
        },
        error: function() {
            //showWarning("There was an issue fetching the url to update the cause for.");
			alert("There was an issue fetching the url to submit knowledge types.");
        }
    });
}

/**
 * Selects the relevance in the existing div when there is already a relevance selected for existing search results.
 *
 * @param url
 * @param searchquery_id
 * @param cnt
 */
function selectRelevanceAndCauseForExistingResult(url, searchquery_id, cnt) {
    //let encodedUrl = url.replaceAll("/", "@2F");
    //encodedUrl = encodedUrl.replaceAll("#", "%23");
	let encodedUrl = encodeURIComponent(url);
	encodedUrl = encodedUrl.replaceAll("%", "@");
    let requesturl = restapi + 'urls/url=' + encodedUrl + '/searchqueryId=' + searchquery_id;
    $.ajax({
        url: requesturl,
        type: "GET",
		timeout:10000,
        success: function(result) {
            let urlObject = result;
            let classNameOfResult = numberToString(cnt);
            if (urlObject.relevance !== null) {
                $("#rel" + urlObject.relevance + classNameOfResult).prop("checked", true);
                let btnSubmitRelevance = $("#btnSubmitRelevance" + classNameOfResult);
                btnSubmitRelevance.attr("disabled", true);
                btnSubmitRelevance.text("Update Relevance");
            }
            if (urlObject.cause !== null) {
                $("#btnSubmitCause" + classNameOfResult).text("Update relevance and knowledge types");
                let causeArray = urlObject.cause.split(',');
                for (var causeCounter = 1; causeCounter <= causeArray.length; causeCounter++) {
                    let causeElement = $("#cause" + causeCounter + classNameOfResult);
                    if (causeCounter !== 7) {
                        if (causeArray[causeCounter - 1] === "true") {
                            causeElement.prop('checked', true);
                        } else {
                            causeElement.prop('checked', false);
                        }
                    } else {
                        let otherInfoArray = causeArray.slice(causeCounter - 1, causeArray.length);
                        let otherInfo = otherInfoArray.join(",");
                        causeElement.val(otherInfo);
                        break;
                    }
                }
            }
        },
        error: function() {
            console.log("This url is probably not a search result yet.");
        }
    });
}

/**
 * Updates the url in the database using a REST call.
 *
 * @param url_id
 * @param urlObject
 * @param ndcgUpdate - this tells us if we need to recompute the ndcg score.
 */
function updateURL(url_id, urlObject, ndcgUpdate) {
    let url = restapi + 'urls/' + url_id;
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        url: url,
        type: 'PUT',
		timeout:10000,
        data: JSON.stringify(urlObject),
        dataType: 'json',
        success: function(result) {
            console.log("SUCCESS UPDATE SEARCHQUERY");
            console.log(result);
            if (ndcgUpdate) {
                //computeNdcg(result.searchqueryid);
            }
        },
        error: function() {
            //showWarning("There was an issue updating the url: " + urlObject.url + ".");
			alert("There was an issue updating the url.");
        }
    });
}

/**
 * This will set the right notification and call showNotification to notify the user of their task decision.
 * @param taskname
 * @param updated
 */
function showNotificationForSelectingTask(taskname, updated) {
    let notification = "";

    if(updated) {
        notification = "You have chosen a new task: " + taskname;
    } else {
        notification = "You have chosen this task: " + taskname;
    }

    showNotification(notification);
}

/**
 * This will set the right notification and call showNotification to notify the user of their task decision.
 * @param pageTitle
 * @param relevanceScore
 * @param updated
 */
function showNotificationForSelectingRelevance(pageTitle, relevanceScore, updated) {
    let notification = "";

    if (updated) {
        notification = "You have updated that the relevance score for \"" +
            pageTitle + "\" has changed to " + convertRelevance(relevanceScore) + ".";
    } else {
        notification = "You have submited the relevance and knowledge types for " + pageTitle + ".";
    }

    showNotification(notification);
}

/**
 * This will set the right notification and call showNotification to notify the user of their cause decision.
 * @param pageTitle
 * @param updated
 */
function showNotificationForSubmittingCause(pageTitle, updated) {
    let notification = "";

    if (updated) {
        notification = "You have updated the cause for the relevance score for \"" +
            pageTitle + "\".";
    } else {
        notification = "You have submitted the knowledge types for \"" +
            pageTitle + "\".";
    }

    showNotification(notification);
}

/**
 * This shows the notification container for 3.5 seconds with the notification to notify the user.
 * @param notification
 */
function showNotification(notification) {
    let notificationDiv = $("#notification");
    let notificationParagraph = $("#notification > p");
    notificationParagraph.text(notification);
    notificationDiv.show();
    setTimeout(function() {
            notificationDiv.hide();
            notificationParagraph.text("");
        },
        3500
    );
}

/**
 * This shows the warning container for 3.5 seconds with the warning to notify the user.
 * @param warning
 */
function showWarning(notification) {
    let notificationDiv = document.createElement("div");
    notificationDiv.id = "warning";
    notificationDiv.className = "plugin";
    let paragraphElement = document.createElement("p");
	paragraphElement.text(notification);
	notificationDiv.appendChild(paragraphElement);
    document.body.appendChild(notificationDiv);
	
	//let notificationDiv = $("#notification");
    //let notificationParagraph = $("#notification > p");
    //paragraphElement.text(notification);
    //notificationDiv.show();
	
    setTimeout(function() {
            notificationDiv.remove();
        },
        3500
    );
}

/* ---------------------------------------------------------------------------------------------------------
 Functions to show the correct widgets and tasks depending on the state.
 */

/**
 * Depending on the current DOM, we need to show our widgets for the search results or
 * for the search engine result page.
 */
function showCorrectWidgets() {
    $(".plugin").show();
    if($("#notification > p").text() === "") $("#notification").hide();
    $("#widget").attr("style", "width: 250px !important");
    $("#taskWidget").hide();
    $("#relevanceWidget").hide();
    if(onGoogle()) {
        console.log("on google");
        $("#taskWidget").show();
        $("#relevanceWidget").hide();
        chrome.storage.local.get(['tasks', 'chosenTask'], function(result) {
            if(result.chosenTask !== undefined && result.chosenTask !== "") {
                $("#taskWidgetHeader").html("Choose a new task");
                $("#selectTask").val(result.chosenTask);
                showAndEnableCorrectEventsInTaskForm();
                hideTaskForm();
                updateTextInWidgets();
                if(onFirstPageOfGoogle()) {
				  if($(".relevanceSERPForm").length === 0) {
						fetchSearchqueriesAndResults();
					}
					$(".relevanceSERPForm").show();
                }
                handleClicks();
            } else {
                $("#selectTask").val("");
                showAndEnableCorrectEventsInTaskForm();
                showTaskForm();
                if($(".relevanceSERPForm").length !== 0) $(".relevanceSERPForm").hide();
            }
        });
    } else {
        chrome.storage.local.get(['chosenTask', 'sessionId'], function(result) {
            if(result.chosenTask !== undefined && result.chosenTask !== "") {
                //let encodedUrl = window.location.href.replaceAll("/", "@2F");
                //encodedUrl = encodedUrl.replaceAll("#", "%23");
				let encodedUrl = encodeURIComponent(window.location.href);
				encodedUrl = encodedUrl.replaceAll("%", "@");
                let url = restapi + 'urls/url=' + encodedUrl + "/sessionId=" + result.sessionId;
                $.ajax({
                    url: url,
                    type: 'GET',
					timeout:10000,
                    success: function (response) {
                        //this means we are on a search result
                        console.log("SUCCESS GET URL BY URL AND SESSION ID");
                        console.log(response);
                        //if we are on a search result, but clicked is false, update search result
                        if(!result.clicked) {
                            result.clicked = true;
                            updateURL(response.id, response);
                        }
                        showWidgetsForSearchResult(response.searchqueryid, response.rankingoogle, response.relevance, result.chosenTask);
                    },
                    error: function () {
                        //this means we are not on a search result
                        $(".plugin").attr("style", "display: none !important");
                    }
                });
            } else {
                $(".plugin").attr("style", "display: none !important"); // because .hide() did not work as expected
            }
        });
    }
}

/**
 * This function only shows the correct widgets and their attributies for a search result, and not on google.
 *
 * @param searchquery_id
 * @param rank
 * @param selectedRelevance
 * @param chosenTask
 */
function showWidgetsForSearchResult(searchquery_id, rank, selectedRelevance, chosenTask) {
    $("#taskWidget").show();
    $("#relevanceWidget").show();
    $("#widget").addClass("" + searchquery_id); // searchqueryid of the search result
    $("#widget").addClass("" + rank); // rank of the search result
    $("#selectTask").val(chosenTask);
    showAndEnableCorrectEventsInTaskForm();
    updateTextInWidgets();
    handleClicks();
    if (selectedRelevance !== null) {
        let id = "rel" + selectedRelevance;
        $("#" + id).prop("checked", true);
        $("#btnSubmitRelevance").parent().addClass("" + selectedRelevance);
        $("#btnSubmitRelevance").attr("disabled", true);
        $("#btnSubmitRelevance").text("Update Relevance");
        hideRelevanceForm();
    }
}

/**
 * Depending on the selected task, we need to disable or enable the select task button and we need to
 * show the correct task description.
 */
function showAndEnableCorrectEventsInTaskForm() {
    let selectedTask = $("#selectTask").val();
    if(selectedTask !== "") {
        $("#taskWidgetHeader").html("Choose a new task");
        $(".taskDescription").show();
        showCorrectTaskDescription(parseInt(selectedTask));
        showTaskDescription();
        // chrome.storage.local.get('chosenTask', function(result) {
        //     $("#btnSelectTask").attr("disabled", !(result.chosenTask !== parseInt(selectedTask)));
        // });
    } else {
        $("#taskWidgetHeader").html("Choose a task");
        $(".taskDescription").hide();
        hideTaskDescription();
        // $("#btnSelectTask").attr("disabled", true);
    }
}

/**
 * This function shows the correct task description and the hide or show task description button.
 *
 * @param taskId
 */
function showCorrectTaskDescription(taskId) {
    $(".taskDescription").show();
    showTaskDescription();
    chrome.storage.local.get('tasks', function(result) {
       $("#taskDescription").html(result.tasks[taskId - 1].description);
    });
}

/* ---------------------------------------------------------------------------------------------------------
 Helper functions.
 */

/**
 * This function calculates the ndcg score of a certain search query.
 *
 * @param searchquery
 */
function computeNdcg(searchquery) {
    let idealRelevanceScores = [];
    let idcg = 0.0;
    let dcg = 0.0;
    let k = true;
    let url = restapi + 'urls/searchqueryId=' + searchquery;
    $.ajax({
        url: url,
        type: 'GET',
		timeout:10000,
        success: function(result) {
            console.log("SUCCESS GET URLS BY SEARCHQUERY");
            console.log(result);
            let allUrls = result;
            
            //Sort the urls on the rankingoogle since they can be added to the database in any order depending on the clicks
            allUrls.sort(function(a, b){return a.rankingoogle - b.rankingoogle});
            
            let relevancePerRank = [];
            for (let i = 0; i < allUrls.length; i++) {
                if(relevancePerRank[allUrls[i].rankingoogle - 1] !== undefined) {
                    if (allUrls[i].score > relevancePerRank[allUrls[i].rankingoogle - 1]) {
                        relevancePerRank[allUrls[i].rankingoogle - 1] = allUrls[i].score;
                        idealRelevanceScores[allUrls[i].rankingoogle - 1] = allUrls[i].score;
                    }
                } else {
                    relevancePerRank[allUrls[i].rankingoogle - 1] = allUrls[i].score;
                    idealRelevanceScores[allUrls[i].rankingoogle - 1] = allUrls[i].score;
                }
            }
            
            // Sort the relevance on the relevance scores for the ideal rankingoogleing
            idealRelevanceScores.sort(function(a, b){return b - a});
            
            for(let i = 0; i < relevancePerRank.length; i++) {
                if(idealRelevanceScores.length > i) {
                    if(idealRelevanceScores[i] !== null) {
                        let score = (Math.pow(2.0, idealRelevanceScores[i]) - 1.0) / (Math.log(i + 2) / Math.log(2));
                        idcg += score;
                    } else {
                        k = false;
                    }
                }
            
                if(k) {
                    dcg += (Math.pow(2.0, relevancePerRank[i]) - 1.0) / (Math.log(i + 2) / Math.log(2));
                }
            }
            let ndcg = 0;
            if (idcg > 0) {
                ndcg = dcg / idcg;
            }
            storeNdcgScore(searchquery, ndcg);
        },
        error: function() {
            //showWarning("There was an error fetching the search results for the search query to calculate the ndcg score.");
			alert("There was an error fetching the search results for the search query to calculate the ndcg score.");
        }
    });
}

/**
 * Function to fetch the search query and the search results from the google
 * search results page.
 */
function fetchSearchqueriesAndResults() {
	chrome.storage.local.get(['selectedTask'], function(result) {
		console.log('selectedTask value currently is ' + result.selectedTask);
		
		// Make sure that the task is selected, otherwise, we do not need to fetch any queries
		if (result.selectedTask) {
		  let searchquery = getSearchquery();
			chrome.storage.local.get(['sessionId', 'tasks', 'chosenTask'], function(result) {
				let currentSession = result.sessionId;
				let encodedSearchquery = searchquery.replaceAll(" ", "%20");
				let url = restapi + 'searchqueries/searchquery=' + encodedSearchquery + '/sessionId=' + currentSession;
				$.ajax({
					url: url,
					type: 'GET',
					timeout:10000,
					success: function(response) {
						console.log("SUCCESS GET SEARCHQUERY BY SEARCHQUERY");
						console.log(result);
						chrome.storage.local.set({'executedQuery': true});
						createRelevanceFormsForSERP(result.tasks[result.chosenTask - 1].taskname, response.id, true);
					},
					error: function() {
						// This means it isn't an already existing search query
						storeSearchquery(searchquery);
					}
				})
			});
		}
	  });
}

/**
 * Gets the search query out of the DOM.
 *
 * @returns {string}
 */
function getSearchquery() {
    var searchquery = document.title;
    searchquery = searchquery.substring(0, searchquery.lastIndexOf("- Google") - 1);
    return searchquery;
}

/**
 * Stores a search query in the database by using a REST call.
 *
 * @param searchquery
 */
function storeSearchquery(searchquery) {
    chrome.storage.local.get(['sessionId', 'tasks', 'chosenTask'], function(result) {
        let data = {searchquery: searchquery, sessionid: result.sessionId, ndcg: null};
        $.ajax({
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            type: 'POST',
			timeout:10000,
            url: restapi + 'searchqueries/add',
            dataType: 'json',
            data: JSON.stringify(data),
            success: function(response) {
                console.log("SUCCESS STORE SEARCHQUERY");
                console.log(response);
				chrome.storage.local.set({'executedQuery': true});
                createRelevanceFormsForSERP(result.tasks[result.chosenTask - 1].taskname, response.id, false);
            },
            error: function() {
                //showWarning("There was a problem creating a new search query record in the database.");
				alert("There was a problem creating a new search query record in the database.");
            }
        });
    });
}

/**
 * This function stores a search result as a url in the database using a REST call.
 *
 * @param url
 * @param rankingoogle
 * @param clicked
 * @param searchquery_id
 */
function storeSearchResult(url, rankingoogle, clicked = false, searchquery_id) {
    let data = {url: url, relevance: null, rankingoogle: rankingoogle, clicked: clicked, searchqueryid: searchquery_id};
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        type: 'POST',
		timeout:10000,
        url: restapi + 'urls/add',
        dataType: 'json',
        data: JSON.stringify(data),
        success: function(result) {
            console.log("SUCCESS STORE URL");
            console.log(result);
        },
        error: function() {
            //showWarning("There was a problem creating a new record in the database for the url: " + url + ".");
			alert("There was a problem creating a new record in the database for the url.");
        }
    });
}

/**
 * Stores the ndcg store by getting the search query out of
 * the database and updating the search query with the ndcg score.
 * @param searchquery_id
 * @param ndcg
 */
function storeNdcgScore(searchquery_id, ndcg) {
    let url = restapi + 'searchqueries/' + searchquery_id;
    $.ajax({
        url: url,
        type: 'GET',
		timeout:10000,
        success: function(result) {
            console.log("SUCCESS GET SEARCHQUERY BY ID");
            console.log(result);
            console.log(ndcg);
            result.ndcg = ndcg;
            updateSearchQuery(result.id, result);
        },
        error: function() {
            //showWarning("There was an issue fetching the search query to update the ndcg score.");
			alert("There was an issue fetching the search query to update the ndcg score.");
        }
    });
}

/**
 * Updates the search query in the database using a REST call.
 *
 * @param searchquery_id
 * @param searchQueryObject
 */
function updateSearchQuery(searchquery_id, searchQueryObject) {
    let url = restapi + 'searchqueries/' + searchquery_id;
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        url: url,
        type: 'PUT',
		timeout:10000,
        data: JSON.stringify(searchQueryObject),
        dataType: 'json',
        success: function(result) {
            console.log("SUCCESS UPDATE SEARCHQUERY");
            console.log(result);
        },
        error: function() {
            //showWarning("There was an issue updating the search query record for search query: " + searchQueryObject.searchquery + ".");
			alert("There was an issue updating the search query record.");
        }
    });
}

/**
 * Updates the clicked field of the url in the database using a REST call
 * by first getting the correct url with a REST call.
 *
 * @param searchResultUrl
 * @param searchquery_id
 */
function updateClickedInUrl(searchResultUrl, searchquery_id) {
    //let encodedUrl = searchResultUrl.replaceAll("/", "@2F");
    //encodedUrl = encodedUrl.replaceAll("#", "%23");
	let encodedUrl = encodeURIComponent(searchResultUrl);
	encodedUrl = encodedUrl.replaceAll("%", "@");
    let url = restapi + 'urls/url=' + encodedUrl + '/searchqueryId=' + searchquery_id;
    $.ajax({
        url: url,
        type: 'GET',
		timeout:10000,
        success: function(result) {
            console.log("SUCCESS GET URL BY URL AND SEARCHQUERY ID");
            console.log(result);
            result.clicked = true;
            updateUrl(result.id, result);
        },
        error: function() {
            //showWarning("There was an issue fetching the url from the database for url: " + searchResultUrl + ".");
			alert("There was an issue fetching the url from the database.");
        }
    })
}

/**
 * Updates the url in the database using a REST call.
 *
 * @param id
 * @param urlObject
 */
function updateUrl(id, urlObject) {
    let url = restapi + 'urls/' + id;
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        url: url,
        type: 'PUT',
		timeout:10000,
        data: JSON.stringify(urlObject),
        dataType: 'json',
        success: function(result) {
            console.log("SUCCESS UPDATE SEARCHQUERY");
            console.log(result);
        },
        error: function() {
            //showWarning("There was an issue updating the url object with url: " + urlObject.url + ".");
			alert("There was an issue updating the url object with url.");
        }
    });
}

/**
 * Updates the session in the database by setting the datetimeFinish to now
 * and by using a REST call.
 *
 * @param sessionId
 * @param sessionObject
 */
function updateSession(sessionId, sessionObject) {
    let url = restapi + 'sessions/' + sessionId;
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        url: url,
        type: 'PUT',
		timeout:10000,
        data: JSON.stringify(sessionObject),
        dataType: 'json',
        success: function(result) {
            console.log("SUCCESS UPDATE SESSION");
            console.log(result);
        },
        error: function() {
            //showWarning("There was an issue updating the session record in the database.");
			alert("There was an issue updating the url object.");
        }
    });
}

/**
 * Appends the contentStyle stylesheet to the content DOM to style the elements we created.
 */
function appendStyleSheet() {
    var style = document.createElement("link");
    style.rel = "stylesheet";
    style.type = "text/css";
    style.href = chrome.extension.getURL("contentStyle.css");
    // (document.head || document.documentElement).appendChild(style);
    (document.body).appendChild(style);
}

/**
 * Function that checks if we are on a google search engine results page
 * @returns {boolean}
 */
function onGoogleSERP() {
    return onGoogle() && location.href.indexOf("search") !== -1;
}

/**
 * Function to check if we are on the first result page of google.
 * @returns {boolean|boolean}
 */
function onFirstPageOfGoogle() {
    return onGoogleSERP() && $(".YyVfkd").text() === "1";
}

/**
 * Function that checks if we are on Google.
 */
function onGoogle() {
    return window.location.href.split("/")[2].indexOf("google") !== -1 && window.location.href.indexOf("tbm") === -1;
}

/**
 * This function converts the relevance score to a description of the score.
 * @param relevance
 * @returns {string}
 */
function convertRelevance(relevance) {
    switch(relevance) {
        case "1":
            return "no relevance";
            break;
        case "2":
            return "low relevance";
            break;
        case "3":
            return "medium relevance";
            break;
        case "4":
            return "high relevance";
            break;
        case "5":
            return "very high relevance";
            break;
    }
}

/**
 * This function converts a number to a string.
 * @param num
 * @returns {string}
 */
function numberToString(num) {
    var strNum = "";
    switch (num) {
        case 0:
            strNum = "zero";
            break;
        case 1:
            strNum = "one";
            break;
        case 2:
            strNum = "two";
            break;
        case 3:
            strNum = "three";
            break;
        case 4:
            strNum = "four";
            break;
        case 5:
            strNum = "five";
            break;
        case 6:
            strNum = "six";
            break;
        case 7:
            strNum = "seven";
            break;
        case 8:
            strNum = "eight";
            break;
        case 9:
            strNum = "nine";
            break;
        case 10:
            strNum = "ten";
            break;
        default:
            strNum = "undefined";
            break;
    }
    return strNum;
}

/**
 * This function converts a string to a number.
 * @param strNum
 * @returns {number}
 */
function stringToNum(strNum) {
    var num = -1;
    switch (strNum) {
        case "zero":
            num = 0;
            break;
        case "one":
            num = 1;
            break;
        case "two":
            num = 2;
            break;
        case "three":
            num = 3;
            break;
        case "four":
            num = 4;
            break;
        case "five":
            num = 5;
            break;
        case "six":
            num = 6;
            break;
        case "seven":
            num = 7;
            break;
        case "eight":
            num = 8;
            break;
        case "nine":
            num = 9;
            break;
    }
    return num;
}