'use strict';

//var bpg = chrome.extension.getBackgroundPage();
var restapi = "https://ec2-3-22-225-201.us-east-2.compute.amazonaws.com/";

/**
 * Initializes the popup.
 */
$(document).ready(function() {
  console.log(chrome.extension.getBackgroundPage());
  //bpg = chrome.extension.getBackgroundPage();
  getLoggedIn();
});

/**
 * Gets the logged_in value from the chrome storage API.
 * Consequently, it shows the correct contents.
 */
function getLoggedIn() {
  chrome.storage.local.get(['logged_in'], function(result) {
    console.log('Logged_in value currently is ' + result.logged_in);
    if (result.logged_in) {
      showContent();
    } else {
      showLogin();
    }
  });
}

/**
 * Show the login form.
 */
function showLogin() {
  emptyLoginForm();
  $("#content").hide();
  $("#loginContainer").show();
  handleLogin();
}

/**
 * Show the content the user needs when they are logged in.
 */
function showContent() {
  emptyLoginForm();
  $("#btnShowDescription").hide();
  $("#content").show();
  $("#loginContainer").hide();
  handleLogout();
}

/**
 * Handles the events on the login page. Such as pressing the log in and cancel button.
 */
function handleLogin() {
  /* This allows the  user to press enter when in the username or
  password input field to press the login button. */
  $("#inpPassword, #inpUsername").on("keyup", function (event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      document.getElementById("btnLogin").click();
    }
  });

  $("#btnLogin").on("click", function () {
    let inputUsername = $('input[name="userid"]').val();
    $.ajax({
      url: restapi + 'accounts/username=' + inputUsername,
      type: 'GET',
	  timeout:10000,
      success: function(result) {
        console.log("SUCCESS GET ACCOUNT");
        console.log(result);
        let accountObject = result;
        if(inputUsername === accountObject.username && $('input[name="password"]').val() === accountObject.password) {
          chrome.storage.local.set({'logged_in': true}, function() {
            console.log('Logged In.');
          });
          chrome.storage.local.set({'user': accountObject.id});
          showContent();
          //bpg.changeLogin();
        } else {
          $("#loginResult").text("Incorrect username or password");
        }
      },
      error: function(error) {
        console.log("GET ACCOUNT ERROR");
        console.log(error);
        $("#loginResult").text("Incorrect username or password");
      }
    });
  });

  //functionality for cancel button
  $("#btnCancel").on("click", function () {
    emptyLoginForm();
	window.close();
  });
}

/**
 * Handles the logging out event.
 */
function handleLogout() {
  $("#btnLogout").on("click", function () {
    chrome.storage.local.get('sessionId', function(result) {
      if(result.sessionId !== undefined && result.sessionId !== "") {
        stopSession(result.sessionId);
      } else {
        resetStorageAndCloseWidget();
      }
    });
    //bpg.changeLogin();
  });
}

/**
 * Function that resets everything such as the storage and widgets.
 */
function resetStorageAndCloseWidget() {
  // Reset widgets
  showLogin();
  resetWidgets();
  $("#selectTask").val("");
  // Reset all flags
  chrome.storage.local.set({'user' : ""});
  chrome.storage.local.set({'chosenTask': ""});
  chrome.storage.local.set({'sessionId': ""});
  chrome.storage.local.set({'selectedTask': false});
  chrome.storage.local.set({'executedQuery': false});
  chrome.storage.local.set({'logged_in': false});
  //Close popup
  window.close();
}

/**
 * Function to tell the content script to
 */
function resetWidgets(){
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
	  for (var i=0; i<tabs.length; ++i) {
			chrome.tabs.sendMessage(tabs[i].id, {greeting: "resetWidgets"}, function(response) {
				console.log(response.farewell);
			});
	  }
	});
}

/**
 * Stops the session by updating the current session using the REST API.
 * @param sessionId
 * @param datetime_finish
 */
function stopSession(sessionId) {
  let datetime_finish = new Date(Date.now());
  console.log("datetime_finish: " + datetime_finish);
  $.ajax({
    url: restapi + '/sessions/' + sessionId,
    type: 'GET',
	timeout:10000,
    success: function(result) {
       console.log("SUCCESS GET SESSION");
       console.log(result);
       let sessionObject = result;
       sessionObject.datetimefinish = datetime_finish;
       updateSession(sessionObject.id, sessionObject);
    },
    error: function(error) {
      console.log("GET SESSION ERROR");
      console.log(error);
    }
  });
}

/**
 * Makes sure the login form is empty and no text remains.
 */
function emptyLoginForm() {
  document.loginForm.password.value = "";
  document.loginForm.userid.value = "";
  document.getElementById("loginResult").innerText = "";
}

/**
 * Updates the session in the database using a REST call.
 * @param sessionId
 * @param sessionObject
 */
function updateSession(sessionId, sessionObject) {
  let url = restapi + 'sessions/' + sessionId;
  $.ajax({
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    url: url,
    type: 'PUT',
	timeout:10000,
    data: JSON.stringify(sessionObject),
    dataType: 'json',
    success: function(result) {
      console.log("SUCCESS UPDATE SESSION");
      console.log(result);
      resetStorageAndCloseWidget();
    },
    error: function(error) {
      console.log("UPDATE SESSION HTTP ERROR:");
      console.log(error);
    }
  });
}