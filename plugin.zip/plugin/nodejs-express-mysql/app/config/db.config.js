module.exports = {
  HOST: "mysql101.service.rug.nl",
  USER: "f117725_31061",
  PASSWORD: "HGj73zOsQDM7KJPxA8VR",
  DB: "f117725_31061"
};
